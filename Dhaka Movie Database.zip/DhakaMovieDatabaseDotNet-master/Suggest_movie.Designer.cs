﻿namespace Dhaka_Movie_Database
{
    partial class Suggest_movie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dmdb_label = new System.Windows.Forms.Label();
            this.suggest_button = new System.Windows.Forms.Button();
            this.movie_name_textBox = new System.Windows.Forms.TextBox();
            this.movie_name_label = new System.Windows.Forms.Label();
            this.log_out_label = new System.Windows.Forms.Label();
            this.update_button = new System.Windows.Forms.Button();
            this.contact_edit_label = new System.Windows.Forms.Label();
            this.name_edit_label = new System.Windows.Forms.Label();
            this.contact_edit_textBox = new System.Windows.Forms.TextBox();
            this.name_edit_textBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.hall_name_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.name_label = new System.Windows.Forms.Label();
            this.contact_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.back_button = new System.Windows.Forms.Button();
            this.s_added = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dmdb_label
            // 
            this.dmdb_label.AutoSize = true;
            this.dmdb_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dmdb_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 47.99999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dmdb_label.Location = new System.Drawing.Point(19, 81);
            this.dmdb_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dmdb_label.Name = "dmdb_label";
            this.dmdb_label.Size = new System.Drawing.Size(279, 91);
            this.dmdb_label.TabIndex = 20;
            this.dmdb_label.Text = "DMDB";
            // 
            // suggest_button
            // 
            this.suggest_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suggest_button.Location = new System.Drawing.Point(241, 350);
            this.suggest_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.suggest_button.Name = "suggest_button";
            this.suggest_button.Size = new System.Drawing.Size(133, 37);
            this.suggest_button.TabIndex = 29;
            this.suggest_button.Text = "Suggest";
            this.suggest_button.UseVisualStyleBackColor = true;
            this.suggest_button.Click += new System.EventHandler(this.suggest_button_Click);
            // 
            // movie_name_textBox
            // 
            this.movie_name_textBox.Location = new System.Drawing.Point(171, 294);
            this.movie_name_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.movie_name_textBox.Name = "movie_name_textBox";
            this.movie_name_textBox.Size = new System.Drawing.Size(288, 22);
            this.movie_name_textBox.TabIndex = 28;
            // 
            // movie_name_label
            // 
            this.movie_name_label.AutoSize = true;
            this.movie_name_label.Location = new System.Drawing.Point(64, 298);
            this.movie_name_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.movie_name_label.Name = "movie_name_label";
            this.movie_name_label.Size = new System.Drawing.Size(86, 17);
            this.movie_name_label.TabIndex = 27;
            this.movie_name_label.Text = "Movie Name";
            // 
            // log_out_label
            // 
            this.log_out_label.AutoSize = true;
            this.log_out_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.log_out_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log_out_label.ForeColor = System.Drawing.Color.Navy;
            this.log_out_label.Location = new System.Drawing.Point(720, 114);
            this.log_out_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.log_out_label.Name = "log_out_label";
            this.log_out_label.Size = new System.Drawing.Size(84, 24);
            this.log_out_label.TabIndex = 92;
            this.log_out_label.Text = "Log Out";
            this.log_out_label.Click += new System.EventHandler(this.log_out_label_Click);
            // 
            // update_button
            // 
            this.update_button.Location = new System.Drawing.Point(692, 646);
            this.update_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.update_button.Name = "update_button";
            this.update_button.Size = new System.Drawing.Size(100, 28);
            this.update_button.TabIndex = 91;
            this.update_button.Text = "Update";
            this.update_button.UseVisualStyleBackColor = true;
            this.update_button.Visible = false;
            this.update_button.Click += new System.EventHandler(this.update_button_Click);
            // 
            // contact_edit_label
            // 
            this.contact_edit_label.AutoSize = true;
            this.contact_edit_label.Location = new System.Drawing.Point(620, 599);
            this.contact_edit_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.contact_edit_label.Name = "contact_edit_label";
            this.contact_edit_label.Size = new System.Drawing.Size(56, 17);
            this.contact_edit_label.TabIndex = 90;
            this.contact_edit_label.Text = "Contact";
            this.contact_edit_label.Visible = false;
            // 
            // name_edit_label
            // 
            this.name_edit_label.AutoSize = true;
            this.name_edit_label.Location = new System.Drawing.Point(620, 549);
            this.name_edit_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.name_edit_label.Name = "name_edit_label";
            this.name_edit_label.Size = new System.Drawing.Size(45, 17);
            this.name_edit_label.TabIndex = 89;
            this.name_edit_label.Text = "Name";
            this.name_edit_label.Visible = false;
            // 
            // contact_edit_textBox
            // 
            this.contact_edit_textBox.Location = new System.Drawing.Point(692, 596);
            this.contact_edit_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.contact_edit_textBox.Name = "contact_edit_textBox";
            this.contact_edit_textBox.Size = new System.Drawing.Size(129, 22);
            this.contact_edit_textBox.TabIndex = 88;
            this.contact_edit_textBox.Visible = false;
            // 
            // name_edit_textBox
            // 
            this.name_edit_textBox.Location = new System.Drawing.Point(692, 549);
            this.name_edit_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.name_edit_textBox.Name = "name_edit_textBox";
            this.name_edit_textBox.Size = new System.Drawing.Size(129, 22);
            this.name_edit_textBox.TabIndex = 87;
            this.name_edit_textBox.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(621, 487);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 86;
            this.button1.Text = "Edit Info";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // hall_name_label
            // 
            this.hall_name_label.AutoSize = true;
            this.hall_name_label.Location = new System.Drawing.Point(743, 406);
            this.hall_name_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hall_name_label.Name = "hall_name_label";
            this.hall_name_label.Size = new System.Drawing.Size(73, 17);
            this.hall_name_label.TabIndex = 85;
            this.hall_name_label.Text = "Hall Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(617, 406);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 84;
            this.label3.Text = "Name :";
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_label.ForeColor = System.Drawing.Color.Navy;
            this.name_label.Location = new System.Drawing.Point(616, 114);
            this.name_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(65, 24);
            this.name_label.TabIndex = 83;
            this.name_label.Text = "Name";
            // 
            // contact_label
            // 
            this.contact_label.AutoSize = true;
            this.contact_label.Location = new System.Drawing.Point(741, 442);
            this.contact_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.contact_label.Name = "contact_label";
            this.contact_label.Size = new System.Drawing.Size(80, 17);
            this.contact_label.TabIndex = 82;
            this.contact_label.Text = "192879123";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(616, 442);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 81;
            this.label1.Text = "Contact :";
            // 
            // back_button
            // 
            this.back_button.Location = new System.Drawing.Point(692, 737);
            this.back_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(100, 28);
            this.back_button.TabIndex = 93;
            this.back_button.Text = "Back";
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // s_added
            // 
            this.s_added.AutoSize = true;
            this.s_added.Location = new System.Drawing.Point(167, 406);
            this.s_added.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.s_added.Name = "s_added";
            this.s_added.Size = new System.Drawing.Size(0, 17);
            this.s_added.TabIndex = 94;
            this.s_added.Visible = false;
            // 
            // Suggest_movie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 794);
            this.Controls.Add(this.s_added);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.log_out_label);
            this.Controls.Add(this.update_button);
            this.Controls.Add(this.contact_edit_label);
            this.Controls.Add(this.name_edit_label);
            this.Controls.Add(this.contact_edit_textBox);
            this.Controls.Add(this.name_edit_textBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hall_name_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.contact_label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.suggest_button);
            this.Controls.Add(this.movie_name_textBox);
            this.Controls.Add(this.movie_name_label);
            this.Controls.Add(this.dmdb_label);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Suggest_movie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Suggest_movie";
            this.Load += new System.EventHandler(this.Suggest_movie_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label dmdb_label;
        private System.Windows.Forms.Button suggest_button;
        private System.Windows.Forms.TextBox movie_name_textBox;
        private System.Windows.Forms.Label movie_name_label;
        private System.Windows.Forms.Label log_out_label;
        private System.Windows.Forms.Button update_button;
        private System.Windows.Forms.Label contact_edit_label;
        private System.Windows.Forms.Label name_edit_label;
        private System.Windows.Forms.TextBox contact_edit_textBox;
        private System.Windows.Forms.TextBox name_edit_textBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label hall_name_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label contact_label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Label s_added;
    }
}