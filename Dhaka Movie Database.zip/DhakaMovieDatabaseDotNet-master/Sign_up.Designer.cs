﻿namespace Dhaka_Movie_Database
{
    partial class Sign_up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dmdb_label = new System.Windows.Forms.Label();
            this.full_name_label = new System.Windows.Forms.Label();
            this.full_name_textBox = new System.Windows.Forms.TextBox();
            this.email_textBox = new System.Windows.Forms.TextBox();
            this.email_label = new System.Windows.Forms.Label();
            this.password_textBox = new System.Windows.Forms.TextBox();
            this.password_label = new System.Windows.Forms.Label();
            this.contact_textBox = new System.Windows.Forms.TextBox();
            this.contact_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.submit_button = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.seat_textbox = new System.Windows.Forms.TextBox();
            this.seat_label = new System.Windows.Forms.Label();
            this.location_textBox = new System.Windows.Forms.TextBox();
            this.location_label = new System.Windows.Forms.Label();
            this.back_button = new System.Windows.Forms.Button();
            this.success_label = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.type_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dmdb_label
            // 
            this.dmdb_label.AutoSize = true;
            this.dmdb_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dmdb_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 47.99999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dmdb_label.Location = new System.Drawing.Point(77, 176);
            this.dmdb_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dmdb_label.Name = "dmdb_label";
            this.dmdb_label.Size = new System.Drawing.Size(279, 91);
            this.dmdb_label.TabIndex = 1;
            this.dmdb_label.Text = "DMDB";
            this.dmdb_label.Click += new System.EventHandler(this.dmdb_label_Click);
            // 
            // full_name_label
            // 
            this.full_name_label.AutoSize = true;
            this.full_name_label.Location = new System.Drawing.Point(375, 306);
            this.full_name_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.full_name_label.Name = "full_name_label";
            this.full_name_label.Size = new System.Drawing.Size(71, 17);
            this.full_name_label.TabIndex = 2;
            this.full_name_label.Text = "Full Name";
            this.full_name_label.Visible = false;
            // 
            // full_name_textBox
            // 
            this.full_name_textBox.Location = new System.Drawing.Point(481, 303);
            this.full_name_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.full_name_textBox.Name = "full_name_textBox";
            this.full_name_textBox.Size = new System.Drawing.Size(288, 22);
            this.full_name_textBox.TabIndex = 3;
            this.full_name_textBox.Visible = false;
            // 
            // email_textBox
            // 
            this.email_textBox.Location = new System.Drawing.Point(481, 351);
            this.email_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.email_textBox.Name = "email_textBox";
            this.email_textBox.Size = new System.Drawing.Size(288, 22);
            this.email_textBox.TabIndex = 5;
            this.email_textBox.Visible = false;
            // 
            // email_label
            // 
            this.email_label.AutoSize = true;
            this.email_label.Location = new System.Drawing.Point(375, 354);
            this.email_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.email_label.Name = "email_label";
            this.email_label.Size = new System.Drawing.Size(42, 17);
            this.email_label.TabIndex = 4;
            this.email_label.Text = "Email";
            this.email_label.Visible = false;
            // 
            // password_textBox
            // 
            this.password_textBox.Location = new System.Drawing.Point(481, 399);
            this.password_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.password_textBox.Name = "password_textBox";
            this.password_textBox.PasswordChar = '*';
            this.password_textBox.Size = new System.Drawing.Size(288, 22);
            this.password_textBox.TabIndex = 7;
            this.password_textBox.Visible = false;
            // 
            // password_label
            // 
            this.password_label.AutoSize = true;
            this.password_label.Location = new System.Drawing.Point(375, 402);
            this.password_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(69, 17);
            this.password_label.TabIndex = 6;
            this.password_label.Text = "Password";
            this.password_label.Visible = false;
            // 
            // contact_textBox
            // 
            this.contact_textBox.Location = new System.Drawing.Point(481, 447);
            this.contact_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.contact_textBox.Name = "contact_textBox";
            this.contact_textBox.Size = new System.Drawing.Size(288, 22);
            this.contact_textBox.TabIndex = 9;
            this.contact_textBox.Visible = false;
            // 
            // contact_label
            // 
            this.contact_label.AutoSize = true;
            this.contact_label.Location = new System.Drawing.Point(375, 450);
            this.contact_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.contact_label.Name = "contact_label";
            this.contact_label.Size = new System.Drawing.Size(56, 17);
            this.contact_label.TabIndex = 8;
            this.contact_label.Text = "Contact";
            this.contact_label.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 130);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(344, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "To suggest movies, Book your seat, please SIGN UP ";
            // 
            // submit_button
            // 
            this.submit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_button.Location = new System.Drawing.Point(481, 610);
            this.submit_button.Margin = new System.Windows.Forms.Padding(4);
            this.submit_button.Name = "submit_button";
            this.submit_button.Size = new System.Drawing.Size(100, 37);
            this.submit_button.TabIndex = 11;
            this.submit_button.Text = "Submit";
            this.submit_button.UseVisualStyleBackColor = true;
            this.submit_button.Visible = false;
            this.submit_button.Click += new System.EventHandler(this.submit_button_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "User",
            "Hall Owner"});
            this.comboBox1.Location = new System.Drawing.Point(116, 297);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(160, 24);
            this.comboBox1.TabIndex = 12;
            this.comboBox1.Text = "Select Type";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // seat_textbox
            // 
            this.seat_textbox.Location = new System.Drawing.Point(481, 545);
            this.seat_textbox.Margin = new System.Windows.Forms.Padding(4);
            this.seat_textbox.Name = "seat_textbox";
            this.seat_textbox.Size = new System.Drawing.Size(288, 22);
            this.seat_textbox.TabIndex = 14;
            this.seat_textbox.Visible = false;
            // 
            // seat_label
            // 
            this.seat_label.AutoSize = true;
            this.seat_label.Location = new System.Drawing.Point(379, 554);
            this.seat_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.seat_label.Name = "seat_label";
            this.seat_label.Size = new System.Drawing.Size(37, 17);
            this.seat_label.TabIndex = 13;
            this.seat_label.Text = "Seat";
            this.seat_label.Visible = false;
            // 
            // location_textBox
            // 
            this.location_textBox.Location = new System.Drawing.Point(481, 492);
            this.location_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.location_textBox.Name = "location_textBox";
            this.location_textBox.Size = new System.Drawing.Size(288, 22);
            this.location_textBox.TabIndex = 16;
            this.location_textBox.Visible = false;
            // 
            // location_label
            // 
            this.location_label.AutoSize = true;
            this.location_label.Location = new System.Drawing.Point(375, 496);
            this.location_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.location_label.Name = "location_label";
            this.location_label.Size = new System.Drawing.Size(62, 17);
            this.location_label.TabIndex = 15;
            this.location_label.Text = "Location";
            this.location_label.Visible = false;
            // 
            // back_button
            // 
            this.back_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_button.Location = new System.Drawing.Point(671, 698);
            this.back_button.Margin = new System.Windows.Forms.Padding(4);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(100, 36);
            this.back_button.TabIndex = 17;
            this.back_button.Text = "Back";
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // success_label
            // 
            this.success_label.AutoSize = true;
            this.success_label.Location = new System.Drawing.Point(477, 718);
            this.success_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.success_label.Name = "success_label";
            this.success_label.Size = new System.Drawing.Size(131, 17);
            this.success_label.TabIndex = 18;
            this.success_label.Text = "Successfully Added";
            this.success_label.Visible = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(157, 354);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(67, 37);
            this.button1.TabIndex = 19;
            this.button1.Text = "Go";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // type_label
            // 
            this.type_label.AutoSize = true;
            this.type_label.ForeColor = System.Drawing.Color.Crimson;
            this.type_label.Location = new System.Drawing.Point(300, 297);
            this.type_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.type_label.Name = "type_label";
            this.type_label.Size = new System.Drawing.Size(137, 17);
            this.type_label.TabIndex = 20;
            this.type_label.Text = "Please Select a type";
            this.type_label.Visible = false;
            // 
            // Sign_up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 761);
            this.Controls.Add(this.type_label);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.success_label);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.location_textBox);
            this.Controls.Add(this.location_label);
            this.Controls.Add(this.seat_textbox);
            this.Controls.Add(this.seat_label);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.submit_button);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.contact_textBox);
            this.Controls.Add(this.contact_label);
            this.Controls.Add(this.password_textBox);
            this.Controls.Add(this.password_label);
            this.Controls.Add(this.email_textBox);
            this.Controls.Add(this.email_label);
            this.Controls.Add(this.full_name_textBox);
            this.Controls.Add(this.full_name_label);
            this.Controls.Add(this.dmdb_label);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Sign_up";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sign_up";
            this.Load += new System.EventHandler(this.Sign_up_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dmdb_label;
        private System.Windows.Forms.Label full_name_label;
        private System.Windows.Forms.TextBox full_name_textBox;
        private System.Windows.Forms.TextBox email_textBox;
        private System.Windows.Forms.Label email_label;
        private System.Windows.Forms.TextBox password_textBox;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.TextBox contact_textBox;
        private System.Windows.Forms.Label contact_label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button submit_button;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox seat_textbox;
        private System.Windows.Forms.Label seat_label;
        private System.Windows.Forms.TextBox location_textBox;
        private System.Windows.Forms.Label location_label;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Label success_label;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label type_label;
    }
}