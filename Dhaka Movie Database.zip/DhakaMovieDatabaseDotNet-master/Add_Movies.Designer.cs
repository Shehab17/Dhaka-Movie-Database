﻿namespace Dhaka_Movie_Database
{
    partial class Add_Movies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.s_added = new System.Windows.Forms.Label();
            this.log_out_label = new System.Windows.Forms.Label();
            this.email_label = new System.Windows.Forms.Label();
            this.Add_button = new System.Windows.Forms.Button();
            this.movie_name_textBox = new System.Windows.Forms.TextBox();
            this.movie_name_label = new System.Windows.Forms.Label();
            this.dmdb_label = new System.Windows.Forms.Label();
            this.rating_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.duration_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.release_year_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.locationedit_label = new System.Windows.Forms.Label();
            this.location_edit_textBox = new System.Windows.Forms.TextBox();
            this.seat_edit_label = new System.Windows.Forms.Label();
            this.seat_edit_textBox = new System.Windows.Forms.TextBox();
            this.update_button = new System.Windows.Forms.Button();
            this.contact_edit_label = new System.Windows.Forms.Label();
            this.name_edit_label = new System.Windows.Forms.Label();
            this.contact_edit_textBox = new System.Windows.Forms.TextBox();
            this.name_edit_textBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.hall_name_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.movie_label = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.location_label = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.seat_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contact_label = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.back_button = new System.Windows.Forms.Button();
            this.category_textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // s_added
            // 
            this.s_added.AutoSize = true;
            this.s_added.Location = new System.Drawing.Point(168, 500);
            this.s_added.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.s_added.Name = "s_added";
            this.s_added.Size = new System.Drawing.Size(0, 17);
            this.s_added.TabIndex = 112;
            this.s_added.Visible = false;
            // 
            // log_out_label
            // 
            this.log_out_label.AutoSize = true;
            this.log_out_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.log_out_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log_out_label.ForeColor = System.Drawing.Color.Navy;
            this.log_out_label.Location = new System.Drawing.Point(737, 79);
            this.log_out_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.log_out_label.Name = "log_out_label";
            this.log_out_label.Size = new System.Drawing.Size(84, 24);
            this.log_out_label.TabIndex = 110;
            this.log_out_label.Text = "Log Out";
            this.log_out_label.Click += new System.EventHandler(this.log_out_label_Click);
            // 
            // email_label
            // 
            this.email_label.AutoSize = true;
            this.email_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_label.ForeColor = System.Drawing.Color.Navy;
            this.email_label.Location = new System.Drawing.Point(633, 79);
            this.email_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.email_label.Name = "email_label";
            this.email_label.Size = new System.Drawing.Size(65, 24);
            this.email_label.TabIndex = 101;
            this.email_label.Text = "Name";
            // 
            // Add_button
            // 
            this.Add_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_button.Location = new System.Drawing.Point(251, 411);
            this.Add_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Add_button.Name = "Add_button";
            this.Add_button.Size = new System.Drawing.Size(100, 37);
            this.Add_button.TabIndex = 98;
            this.Add_button.Text = "Add";
            this.Add_button.UseVisualStyleBackColor = true;
            this.Add_button.Click += new System.EventHandler(this.Add_button_Click);
            // 
            // movie_name_textBox
            // 
            this.movie_name_textBox.Location = new System.Drawing.Point(172, 172);
            this.movie_name_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.movie_name_textBox.Name = "movie_name_textBox";
            this.movie_name_textBox.Size = new System.Drawing.Size(288, 22);
            this.movie_name_textBox.TabIndex = 97;
            // 
            // movie_name_label
            // 
            this.movie_name_label.AutoSize = true;
            this.movie_name_label.Location = new System.Drawing.Point(52, 176);
            this.movie_name_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.movie_name_label.Name = "movie_name_label";
            this.movie_name_label.Size = new System.Drawing.Size(86, 17);
            this.movie_name_label.TabIndex = 96;
            this.movie_name_label.Text = "Movie Name";
            // 
            // dmdb_label
            // 
            this.dmdb_label.AutoSize = true;
            this.dmdb_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dmdb_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 47.99999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dmdb_label.Location = new System.Drawing.Point(36, 46);
            this.dmdb_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dmdb_label.Name = "dmdb_label";
            this.dmdb_label.Size = new System.Drawing.Size(279, 91);
            this.dmdb_label.TabIndex = 95;
            this.dmdb_label.Text = "DMDB";
            // 
            // rating_textBox
            // 
            this.rating_textBox.Location = new System.Drawing.Point(172, 218);
            this.rating_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rating_textBox.Name = "rating_textBox";
            this.rating_textBox.Size = new System.Drawing.Size(288, 22);
            this.rating_textBox.TabIndex = 114;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 222);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 113;
            this.label2.Text = "Rating";
            // 
            // duration_textBox
            // 
            this.duration_textBox.Location = new System.Drawing.Point(172, 304);
            this.duration_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.duration_textBox.Name = "duration_textBox";
            this.duration_textBox.Size = new System.Drawing.Size(288, 22);
            this.duration_textBox.TabIndex = 118;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 308);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 17);
            this.label4.TabIndex = 117;
            this.label4.Text = "Duration";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(52, 262);
            this.label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(65, 17);
            this.label.TabIndex = 115;
            this.label.Text = "Category";
            // 
            // release_year_textBox
            // 
            this.release_year_textBox.Location = new System.Drawing.Point(172, 348);
            this.release_year_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.release_year_textBox.Name = "release_year_textBox";
            this.release_year_textBox.Size = new System.Drawing.Size(288, 22);
            this.release_year_textBox.TabIndex = 120;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(52, 352);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 17);
            this.label6.TabIndex = 119;
            this.label6.Text = "Release Year";
            // 
            // locationedit_label
            // 
            this.locationedit_label.AutoSize = true;
            this.locationedit_label.Location = new System.Drawing.Point(617, 523);
            this.locationedit_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.locationedit_label.Name = "locationedit_label";
            this.locationedit_label.Size = new System.Drawing.Size(62, 17);
            this.locationedit_label.TabIndex = 140;
            this.locationedit_label.Text = "Location";
            this.locationedit_label.Visible = false;
            // 
            // location_edit_textBox
            // 
            this.location_edit_textBox.Location = new System.Drawing.Point(689, 519);
            this.location_edit_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.location_edit_textBox.Name = "location_edit_textBox";
            this.location_edit_textBox.Size = new System.Drawing.Size(129, 22);
            this.location_edit_textBox.TabIndex = 139;
            this.location_edit_textBox.Visible = false;
            // 
            // seat_edit_label
            // 
            this.seat_edit_label.AutoSize = true;
            this.seat_edit_label.Location = new System.Drawing.Point(617, 491);
            this.seat_edit_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.seat_edit_label.Name = "seat_edit_label";
            this.seat_edit_label.Size = new System.Drawing.Size(37, 17);
            this.seat_edit_label.TabIndex = 138;
            this.seat_edit_label.Text = "Seat";
            this.seat_edit_label.Visible = false;
            // 
            // seat_edit_textBox
            // 
            this.seat_edit_textBox.Location = new System.Drawing.Point(689, 487);
            this.seat_edit_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.seat_edit_textBox.Name = "seat_edit_textBox";
            this.seat_edit_textBox.Size = new System.Drawing.Size(129, 22);
            this.seat_edit_textBox.TabIndex = 137;
            this.seat_edit_textBox.Visible = false;
            // 
            // update_button
            // 
            this.update_button.Location = new System.Drawing.Point(689, 575);
            this.update_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.update_button.Name = "update_button";
            this.update_button.Size = new System.Drawing.Size(100, 30);
            this.update_button.TabIndex = 136;
            this.update_button.Text = "Update";
            this.update_button.UseVisualStyleBackColor = true;
            this.update_button.Visible = false;
            this.update_button.Click += new System.EventHandler(this.update_button_Click);
            // 
            // contact_edit_label
            // 
            this.contact_edit_label.AutoSize = true;
            this.contact_edit_label.Location = new System.Drawing.Point(617, 459);
            this.contact_edit_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.contact_edit_label.Name = "contact_edit_label";
            this.contact_edit_label.Size = new System.Drawing.Size(56, 17);
            this.contact_edit_label.TabIndex = 135;
            this.contact_edit_label.Text = "Contact";
            this.contact_edit_label.Visible = false;
            // 
            // name_edit_label
            // 
            this.name_edit_label.AutoSize = true;
            this.name_edit_label.Location = new System.Drawing.Point(617, 423);
            this.name_edit_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.name_edit_label.Name = "name_edit_label";
            this.name_edit_label.Size = new System.Drawing.Size(45, 17);
            this.name_edit_label.TabIndex = 134;
            this.name_edit_label.Text = "Name";
            this.name_edit_label.Visible = false;
            // 
            // contact_edit_textBox
            // 
            this.contact_edit_textBox.Location = new System.Drawing.Point(689, 455);
            this.contact_edit_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.contact_edit_textBox.Name = "contact_edit_textBox";
            this.contact_edit_textBox.Size = new System.Drawing.Size(129, 22);
            this.contact_edit_textBox.TabIndex = 133;
            this.contact_edit_textBox.Visible = false;
            // 
            // name_edit_textBox
            // 
            this.name_edit_textBox.Location = new System.Drawing.Point(689, 423);
            this.name_edit_textBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.name_edit_textBox.Name = "name_edit_textBox";
            this.name_edit_textBox.Size = new System.Drawing.Size(129, 22);
            this.name_edit_textBox.TabIndex = 132;
            this.name_edit_textBox.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(621, 367);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 131;
            this.button1.Text = "Edit Info";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // hall_name_label
            // 
            this.hall_name_label.AutoSize = true;
            this.hall_name_label.Location = new System.Drawing.Point(747, 170);
            this.hall_name_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hall_name_label.Name = "hall_name_label";
            this.hall_name_label.Size = new System.Drawing.Size(73, 17);
            this.hall_name_label.TabIndex = 130;
            this.hall_name_label.Text = "Hall Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(621, 170);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 129;
            this.label3.Text = "Name :";
            // 
            // movie_label
            // 
            this.movie_label.AutoSize = true;
            this.movie_label.Location = new System.Drawing.Point(747, 324);
            this.movie_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.movie_label.Name = "movie_label";
            this.movie_label.Size = new System.Drawing.Size(63, 17);
            this.movie_label.TabIndex = 128;
            this.movie_label.Text = "(dummy)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(621, 324);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 17);
            this.label10.TabIndex = 127;
            this.label10.Text = "Movie";
            // 
            // location_label
            // 
            this.location_label.AutoSize = true;
            this.location_label.Location = new System.Drawing.Point(747, 284);
            this.location_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.location_label.Name = "location_label";
            this.location_label.Size = new System.Drawing.Size(63, 17);
            this.location_label.TabIndex = 126;
            this.location_label.Text = "(dummy)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(621, 284);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 17);
            this.label8.TabIndex = 125;
            this.label8.Text = "Location :";
            // 
            // seat_label
            // 
            this.seat_label.AutoSize = true;
            this.seat_label.Location = new System.Drawing.Point(745, 241);
            this.seat_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.seat_label.Name = "seat_label";
            this.seat_label.Size = new System.Drawing.Size(83, 17);
            this.seat_label.TabIndex = 124;
            this.seat_label.Text = "4.5(dummy)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(620, 241);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 123;
            this.label1.Text = "Seat :";
            // 
            // contact_label
            // 
            this.contact_label.AutoSize = true;
            this.contact_label.Location = new System.Drawing.Point(745, 206);
            this.contact_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.contact_label.Name = "contact_label";
            this.contact_label.Size = new System.Drawing.Size(80, 17);
            this.contact_label.TabIndex = 122;
            this.contact_label.Text = "192879123";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(620, 206);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.TabIndex = 121;
            this.label5.Text = "Contact :";
            // 
            // back_button
            // 
            this.back_button.Location = new System.Drawing.Point(689, 638);
            this.back_button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(100, 30);
            this.back_button.TabIndex = 141;
            this.back_button.Text = "Back";
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // category_textBox
            // 
            this.category_textBox.Location = new System.Drawing.Point(172, 259);
            this.category_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.category_textBox.Name = "category_textBox";
            this.category_textBox.Size = new System.Drawing.Size(288, 22);
            this.category_textBox.TabIndex = 142;
            // 
            // Add_Movies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 775);
            this.Controls.Add(this.category_textBox);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.locationedit_label);
            this.Controls.Add(this.location_edit_textBox);
            this.Controls.Add(this.seat_edit_label);
            this.Controls.Add(this.seat_edit_textBox);
            this.Controls.Add(this.update_button);
            this.Controls.Add(this.contact_edit_label);
            this.Controls.Add(this.name_edit_label);
            this.Controls.Add(this.contact_edit_textBox);
            this.Controls.Add(this.name_edit_textBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hall_name_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.movie_label);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.location_label);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.seat_label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.contact_label);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.release_year_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.duration_textBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label);
            this.Controls.Add(this.rating_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.s_added);
            this.Controls.Add(this.log_out_label);
            this.Controls.Add(this.email_label);
            this.Controls.Add(this.Add_button);
            this.Controls.Add(this.movie_name_textBox);
            this.Controls.Add(this.movie_name_label);
            this.Controls.Add(this.dmdb_label);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Add_Movies";
            this.Text = "Add_Movies";
            this.Load += new System.EventHandler(this.Add_Movies_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label s_added;
        private System.Windows.Forms.Label log_out_label;
        private System.Windows.Forms.Label email_label;
        private System.Windows.Forms.Button Add_button;
        private System.Windows.Forms.TextBox movie_name_textBox;
        private System.Windows.Forms.Label movie_name_label;
        private System.Windows.Forms.Label dmdb_label;
        private System.Windows.Forms.TextBox rating_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox duration_textBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox release_year_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label locationedit_label;
        private System.Windows.Forms.TextBox location_edit_textBox;
        private System.Windows.Forms.Label seat_edit_label;
        private System.Windows.Forms.TextBox seat_edit_textBox;
        private System.Windows.Forms.Button update_button;
        private System.Windows.Forms.Label contact_edit_label;
        private System.Windows.Forms.Label name_edit_label;
        private System.Windows.Forms.TextBox contact_edit_textBox;
        private System.Windows.Forms.TextBox name_edit_textBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label hall_name_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label movie_label;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label location_label;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label seat_label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label contact_label;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.TextBox category_textBox;
    }
}